import java.sql.*;

public class DBConnection {

    public static Connection getConnection() {
        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                "jdbc:mysql://sql.freedb.tech:3306/freedb_java_student",
                "freedb_rehan",
                "Z9WYjk%vDhX&Yxr"
            );

            System.out.println("Connected to Online DB ✅");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return con;
    }
}