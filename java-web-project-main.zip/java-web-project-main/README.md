# 🎓 Student Management System

## 📌 Project Description

This is a web-based Student Management System developed using Java Servlets.
It allows users to add and manage student records using an **online MySQL database (FreeDB)**.

\---

## 🚀 Features

* ➕ Add Student
* 👀 View Students
* 🌐 Uses Online Database (FreeDB)
* 💻 Simple Web Interface

\---

## 🛠️ Technologies Used

* Java (Servlets)
* HTML / CSS
* Apache Tomcat 10
* MySQL (FreeDB - Online Database)
* JDBC (MySQL Connector)

\---

## 🌐 Database Configuration

This project uses an online database hosted on FreeDB.

To run this project, update the database connection in `DBConnection.java`:

```java
jdbc:mysql://sql.freedb.tech:3306/freedb\_java\_student
```

\---

## ⚙️ How to Run the Project

1. Import project into Eclipse
2. Configure Apache Tomcat 10 server
3. Add MySQL Connector `.jar` in `WEB-INF/lib`
4. Update database credentials
5. Run on server
6. Open browser:
`http://localhost:8080/freedb\_java\_student/`

\---

## 🔐 Note

Database credentials are not included for security reasons.
Use your own FreeDB account to connect.

\---

## 👨‍💻 Author

Vivek gajjar

\---

